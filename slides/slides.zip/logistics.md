## Intros

 - Hello! I am:

   - Ant Weiss ([@antweiss](https://twitter.com/antweiss), Otomato Software Delivery.)

- This is a full day workshop

- Feel free to interrupt for questions at any time

- *Especially when you see full screen ship pictures!*

- Live feedback, questions, help: @@CHAT@@
