class: title, in-person

@@TITLE@@<br/></br>



.footnote[
*Presented by Anton Weiss*<br/>
*Otomato technical training.*<br/>
*http://otomato.link*

**Slides: @@SLIDES@@**

*Slide-generation engine borrowed from [container.training](https://github.com/jpetazzo/container.training)*

]



