# Analyzing Our Canaries

- In order to have real CD - we usually don't want to promote our rollouts manually

- But in order to roll out automatically we need some verification

- Argo Rollouts allows us to analyze our canaries based on telemetry

- It integrates with multiple telemetry providers - Prometheus, DataDog, NewRelic, CloudWatch, InfluxDB.

- Let's see how to use it with Prometheus.

---

## Deploy Prometheus

.exercise[
```bash
kubectl apply -f prometheus.yaml
# and an ingress for prometheus
MY_IP=$(dig +short myip.opendns.com @resolver1.opendns.com)
sed -i s/\<MY_IP\>/$MY_IP/ prometheus-ingress.yaml
kubectl apply -f prometheus-ingress.yaml
```
]

---
