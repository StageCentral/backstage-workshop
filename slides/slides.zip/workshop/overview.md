# Platform Engineering Defined


---

## What's an IDP


---

## Components of an IDP

---

## Why Backstage


---

## Backstage History

---
## What are we going to learn

