layout: true

<div class="my-header"><img src="images/otologo.png" style="height: 30px;"/></div>
<div class="my-footer"><span>&copy; 2022 - 2022 Otomato, Ltd.</span></div>