# Summing It All Up




---

## That's It for Today!

- Thanks for attending!

- Any future questions: `anton@stagecentral.io`

- Follow me on twitter - @antweiss

- For more training : https://devopstrain.pro