# Summing It All Up

- We've learned what progressive delivery is

- We've learned how Argo Rollouts works

- We've seen how to integrate Rollouts with:
  
  -  Traefik ingress controller for traffic management

  -  Prometheus for Analysis


---

## That's It for Today!

- Thanks for attending!

- Any future questions: `anton@otomato.io`

- Follow me on twitter - @antweiss

- For more training : https://devopstrain.pro