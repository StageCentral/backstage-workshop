# The Rollouts Dashboard

The Argo Rollouts Kubectl plugin can serve a local UI Dashboard to visualize your Rollouts.

Let's  take a look:

.exercise[
    ```bash
    kar dashboard
    ```
]

Then visit localhost:3100 to view the user interface.

